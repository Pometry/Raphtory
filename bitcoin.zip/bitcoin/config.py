__author__ = "haaroony"

'''
Config files
- Program Wide Variables
'''

BITCOIN_RPC_PORT = 8332
BITCOIN_CONF_LOC = "/home/moe/.bitcoin/bitcoin.conf"
POSTGRES_USER = "moe"
POSTGRES_PASS = "1234"
POSTGRES_DB = "bitcoin"

